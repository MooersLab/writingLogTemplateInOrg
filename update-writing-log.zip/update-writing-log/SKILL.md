---
name: update-writing-log
description: >
  Append a dated daily entry to the Daily Log of an org-mode project log file
  (usually named logNNNN.org, where NNNN is the project index). Use this skill
  when the user asks to "update my writing log", "log today's progress", "add a
  daily log entry", "write up what I did today", "update logNNNN.org", or
  "record today's accomplishments". The skill finds the top-level "* Daily Log"
  headline, gathers what was accomplished today from the session, git history,
  and recently changed files, then inserts a new "** YYYY-MM-DD" entry at the
  bottom of the dated entries with a summary and an org-mode follow-up checklist.
version: 0.1.0
---

# Update Writing Log

Add one dated entry to the Daily Log section of an org-mode project log. The new
entry carries the current date as a second-level headline, a summary of what was
accomplished, and a follow-up checklist of next actions. The entry is placed at
the bottom of the existing dated entries, before any trailing non-date
subheadings, and nothing else in the file is changed.

## When to use

Trigger on requests such as "update my writing log", "log today's progress",
"add today's entry to logNNNN.org", or "record what I got done today". The skill
operates on the project's org log, not on the manuscript.

## Inputs and defaults

| Input | How to obtain | Default |
| --- | --- | --- |
| Log file | A file named `logNNNN.org` in the project folder | Glob `log*.org` in the current/selected folder; if several, ask which |
| Current date | Run `date +%F` in the shell | Today, formatted `YYYY-MM-DD` |
| What was accomplished | The session so far, plus git and file evidence (see Phase 2) | Ask the user only if no evidence is found |
| Project index `NNNN` | Read from the log filename or the folder name | Inferred, used only for the report |

## Workflow

### Phase 0: Locate the log file
Find `log*.org` in the project (selected) folder. If exactly one matches, use it.
If several match, list them and ask which project. If none matches, ask the user
for the path. Record the project index `NNNN` from the filename for the report.

### Phase 1: Read the file and map the Daily Log section
Read the whole log. Find the single top-level headline `* Daily Log`. The dated
entries inside it are second-level headlines of the form `** YYYY-MM-DD`. The
section may also contain non-date second-level headlines that follow the dated
entries, for example `** Bridge to next session` or `** To be done or could be
done`. The new entry must go AFTER the last dated entry and BEFORE those trailing
subheadings, never at the very end of the section. Read the most recent dated
entry to learn the window since the last update, and read any `** Bridge to next
session` notes, because they often state exactly what this session set out to do.

### Phase 2: Gather what was accomplished
Build the summary from evidence, not assumption. Combine, in order:
1. The current conversation and session, which is the primary source of what was
   done today.
2. Git activity since the last entry date, for example
   `git -C <project> log --since="<last-entry-date>" --pretty=format:"%h %s"` and
   `git -C <project> shortlog -s -n --since=...`.
3. Files changed today, for example `find <project> -type f -newermt "today 00:00" -not -path "*/.git/*"`.
4. Any "next session" intentions recorded in the previous Bridge note.

If none of these yield anything concrete, ask the user what they accomplished
before writing. Never invent progress.

### Phase 3: Draft the entry
Compose, in this order, under the date headline:
- A summary. Use one or more short narrative paragraphs when the day is a single
  thread of work, or a bullet list when there are several distinct
  accomplishments. Match the form already used in recent entries when in doubt.
- A follow-up checklist of next actions as native org checkboxes.
Apply the house style below to all prose. Get the date from `date +%F`.

### Phase 4: Insert the entry
Place the new entry after the last dated entry and before any trailing non-date
subheading. Prefer the bundled helper for deterministic placement:

```bash
python3 scripts/update_log.py --log <path/to/logNNNN.org> --body <body.org> --date "$(date +%F)"
```

`body.org` holds the content that goes UNDER the date headline (the summary plus
the follow-up subtree); the script writes the `** YYYY-MM-DD` line itself and
saves a `.bak` backup first. If an entry for today already exists, the script
appends to it by default (`--if-exists append`); use `--if-exists replace` to
rewrite today's entry or `--if-exists abort` to stop. You may instead make the
edit directly with the Edit tool when you need to merge carefully into an
existing entry; if so, still place it in the same position and keep a backup.

### Phase 5: Verify and report
Confirm the new `** YYYY-MM-DD` headline exists once, sits directly after the
previous dated entry and before any non-date subheading, and that the follow-up
items are real org checkboxes (`- [ ] `). Confirm no other entry was moved or
altered. Report the entry that was added and the file path. When you echo the
follow-up checklist back in chat, wrap it in a `#+begin_src org ... #+end_src`
block, because the user prefers returned to-do lists inside an org source block.

## Entry template

```org
** 2026-05-29
One or two short narrative sentences describing the day's work, one sentence per line.
Or, when there are several distinct items, a bullet list:
- Did X.
- Finished Y.
- Started Z.

*** Follow-up
- [ ] First next action.
- [ ] Second next action.
```

Use `** YYYY-MM-DD` exactly, with no time-of-day and no active timestamp unless
the user asks for one. The follow-up list lives under a `*** Follow-up`
sub-subheading by default; if the user prefers no extra heading, place the
checklist directly beneath the summary instead. In the log file the checklist is
a NATIVE org checklist so the checkboxes stay interactive; the user's
minted-code-block preference for to-do lists applies only to LaTeX documents and
to chat replies, not to this org file.

## House style (apply to all prose in the entry)
- Do not use em-dashes. Reword instead.
- Do not use a colon to join two independent clauses. A colon before a list is fine.
- Use "because" for causation. Reserve "since" for time.
- Expand contractions: write "do not", "cannot", "it is".
- Write one sentence per line in narrative summaries.
- Plain ASCII. Keep the tone concise and factual.

## Guardrails
- Back up the log before writing (the helper writes `logNNNN.org.bak`).
- Change only the Daily Log section. Never reorder, edit, or delete existing entries.
- Preserve the trailing non-date subheadings (Bridge, To be done) below the new entry.
- Do not create a second entry for a date that already has one; append or replace.
- Summarize only verifiable work. If evidence is thin, ask rather than embellish.
- Keep the file valid org. Do not alter the preamble, properties drawers, or tags.

## Bundled assets
- `scripts/update_log.py` — finds `* Daily Log`, places a `** YYYY-MM-DD` entry
  after the last dated entry and before any non-date subheading, supports
  `--if-exists append|replace|abort`, writes a `.bak` backup, and offers
  `--dry-run` to preview the rewritten section.
