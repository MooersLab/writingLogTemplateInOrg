#!/usr/bin/env python3
"""Insert a dated daily-log entry into an org-mode project log.

The log has a single top-level headline "* Daily Log" somewhere in the
middle of the file. Dated entries are second-level headlines of the form
"** YYYY-MM-DD". The Daily Log section may also contain non-date second-level
headlines (for example "** Bridge to next session") that follow the dated
entries. A new dated entry must be placed AFTER the last dated entry and
BEFORE any trailing non-date subheadings, never at the very end of the
section.

Usage:
  update_log.py --log log0679.org --body body.org [--date YYYY-MM-DD]
                [--if-exists append|replace|abort] [--no-backup] [--dry-run]

--body is a file holding the org content that goes UNDER the date headline
(the summary plus the follow-up checklist). Do not include the "** YYYY-MM-DD"
line in the body; this script writes it.
"""
import argparse
import datetime
import re
import shutil
import sys
from pathlib import Path

TOP = re.compile(r"^\*\s")            # one star + space  -> top-level headline
SUB = re.compile(r"^\*\*\s")          # two stars + space -> second-level headline
DAILY_LOG = re.compile(r"^\*\s+Daily\s+Log(\s|:|$)", re.IGNORECASE)


def date_headline(line):
    m = re.match(r"^\*\*\s+(\d{4}-\d{2}-\d{2})\b", line)
    return m.group(1) if m else None


def find_section(lines):
    """Return (headline_idx, section_end_excl) for the Daily Log section."""
    dl = next((i for i, ln in enumerate(lines) if DAILY_LOG.match(ln)), None)
    if dl is None:
        return None
    end = len(lines)
    for j in range(dl + 1, len(lines)):
        if TOP.match(lines[j]):          # next top-level headline ends the section
            end = j
            break
    return dl, end


def subtree_end(lines, start, section_end):
    """Index where the second-level subtree beginning at `start` ends."""
    for j in range(start + 1, section_end):
        if SUB.match(lines[j]) or TOP.match(lines[j]):
            return j
    return section_end


def build_block(date, body):
    body = body.rstrip("\n")
    return [f"** {date}\n"] + [l + "\n" for l in body.split("\n")] + ["\n"]


def main():
    ap = argparse.ArgumentParser(description="Append a dated entry to an org Daily Log.")
    ap.add_argument("--log", required=True)
    ap.add_argument("--body", required=True, help="File with the entry body (no date headline).")
    ap.add_argument("--date", default=datetime.date.today().isoformat())
    ap.add_argument("--if-exists", choices=["append", "replace", "abort"], default="append",
                    help="What to do if an entry for --date already exists.")
    ap.add_argument("--no-backup", action="store_true")
    ap.add_argument("--dry-run", action="store_true", help="Print the new Daily Log section, do not write.")
    args = ap.parse_args()

    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", args.date):
        sys.exit(f"--date must be YYYY-MM-DD, got {args.date!r}")

    log = Path(args.log)
    lines = log.read_text(encoding="utf-8").splitlines(keepends=True)
    body = Path(args.body).read_text(encoding="utf-8")

    sec = find_section(lines)
    if sec is None:
        sys.exit('Could not find a top-level "* Daily Log" headline in the file.')
    dl, end = sec

    # Existing entry for this date?
    existing = next((i for i in range(dl + 1, end) if date_headline(lines[i]) == args.date), None)

    block = build_block(args.date, body)

    if existing is not None:
        if args.if_exists == "abort":
            sys.exit(f"An entry for {args.date} already exists at line {existing + 1}. Aborting.")
        st_end = subtree_end(lines, existing, end)
        if args.if_exists == "replace":
            new_lines = lines[:existing] + block + lines[st_end:]
        else:  # append body under the existing date headline
            insert = st_end
            while insert - 1 > existing and lines[insert - 1].strip() == "":
                insert -= 1
            add = [l + "\n" for l in body.rstrip("\n").split("\n")] + ["\n"]
            if lines[insert - 1].strip() != "":
                add = ["\n"] + add
            new_lines = lines[:insert] + add + lines[insert:]
    else:
        # Place after the last DATED entry, before any trailing non-date subheadings.
        date_idxs = [i for i in range(dl + 1, end) if date_headline(lines[i])]
        if date_idxs:
            insert = subtree_end(lines, date_idxs[-1], end)
        else:
            sub_idxs = [i for i in range(dl + 1, end) if SUB.match(lines[i])]
            insert = sub_idxs[0] if sub_idxs else end
        # trim blank lines immediately before the insertion point
        while insert - 1 > dl and lines[insert - 1].strip() == "":
            insert -= 1
        # ensure exactly one blank line separates the previous content from the new entry
        new_lines = lines[:insert] + ["\n"] + block + lines[insert:]

    if args.dry_run:
        s2 = find_section(new_lines)
        a, b = s2
        sys.stdout.write("".join(new_lines[a:b]))
        return

    if not args.no_backup:
        shutil.copy2(log, log.with_suffix(log.suffix + ".bak"))
    log.write_text("".join(new_lines), encoding="utf-8")
    print(f"Wrote entry for {args.date} to {log} (backup: {log.name}.bak unless disabled).")


if __name__ == "__main__":
    main()
